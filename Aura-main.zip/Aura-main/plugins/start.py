# Don't Remove Credit @CodeFlix_Bots, @rohit_1888
# Ask Doubt on telegram @CodeflixSupport
#
# Copyright (C) 2025 by Codeflix-Bots@Github, < https://github.com/Codeflix-Bots >.
#
# This file is part of < https://github.com/Codeflix-Bots/FileStore > project,
# and is released under the MIT License.
# Please see < https://github.com/Codeflix-Bots/FileStore/blob/master/LICENSE >
#
# All rights reserved.

import asyncio
import os
import random
import sys
import re
import string
import string as rohit
import time
from datetime import datetime, timedelta
from pytz import timezone
from pyrogram import Client, filters, __version__
from pyrogram.enums import ParseMode, ChatAction
from pyrogram.types import (
    Message, InlineKeyboardMarkup, InlineKeyboardButton,
    CallbackQuery, ReplyKeyboardMarkup, ChatInviteLink, ChatPrivileges
)
from pyrogram.errors.exceptions.bad_request_400 import UserNotParticipant
from pyrogram.errors import FloodWait, UserIsBlocked, InputUserDeactivated
from bot import Bot
from config import *
from helper_func import is_admin, is_subscribed, decode, get_messages, get_exp_time, wrap_with_redirect, get_shortlink, admin
from database.database import *
from database.db_premium import *

BAN_SUPPORT = f"{BAN_SUPPORT}"
TUT_VID = f"{TUT_VID}"

# Create a global dictionary to store chat data
chat_data_cache = {}

@Bot.on_message(filters.command('start') & filters.private)
async def start_command(client: Client, message: Message):
    user_id = message.from_user.id
    id = message.from_user.id
    is_premium = await is_premium_user(id)

    # Add user if not exists
    if not await db.present_user(user_id):
        try:
            await db.add_user(user_id)
        except:
            pass

    # Force Subscribe
    if not await is_subscribed(client, user_id):
        return await not_joined(client, message)

    # Banned?
    banned_users = await db.get_ban_users()
    if user_id in banned_users:
        return await message.reply_text(
            "<b>⛔️ You are Bᴀɴɴᴇᴅ from using this bot.</b>\n\n"
            "<i>Contact support if you think this is a mistake.</i>",
            reply_markup=InlineKeyboardMarkup(
                [[InlineKeyboardButton("Contact Support", url=BAN_SUPPORT)]]
            )
        )

    FILE_AUTO_DELETE = await db.get_del_timer()
    settings = await db.get_settings()
    text = message.text

    if len(text) > 7:
        verify_status = await db.get_verify_status(id)

        # Token expiry
        if (settings['is_shortlink']):
            if verify_status['is_verified'] and VERIFY_EXPIRE < (time.time() - verify_status['verified_time']):
                await db.update_verify_status(user_id, is_verified=False, verify_token="", original_start="")

        # === VERIFY TOKEN (User came back after shortlink) ===
        if message.text.startswith("/start verify_"):
            _, token = message.text.split("verify_", 1)
            if verify_status['verify_token'] != token:
                return await message.reply("Invalid token. Please /start again.")

            await db.update_verify_status(
                user_id,
                is_verified=True,
                verified_time=time.time()
            )
            current = await db.get_verify_count(id)
            await db.set_verify_count(id, current + 1)

            original_start = verify_status.get('original_start', '')
            if not original_start:
                return await message.reply("No file found. Please try again.")

            btn = InlineKeyboardMarkup([
                [InlineKeyboardButton("GET FILE", url=f"https://t.me/{client.username}?start={original_start}")]
            ])
            return await message.reply(
                f"Token verified!\nValid for {get_exp_time(VERIFY_EXPIRE)}\n\n"
                "Click below to get your file",
                reply_markup=btn
            )

        # === NOT VERIFIED & NOT PREMIUM → SHOW SHORTLINK ===
        if not verify_status['is_verified'] and not is_premium:
            if settings['is_shortlink']:
                try:
                    original_cmd = text.split(" ", 1)[1]
                except:
                    return await message.reply("Invalid link.")

                token = ''.join(random.choices(string.ascii_letters + string.digits, k=10))
                verify_link = f"https://t.me/{client.username}?start=verify_{token}"
                shortlink = await get_shortlink(settings['shortlink_url'], settings['shortlink_api'], verify_link)
                masked_link = await wrap_with_redirect(shortlink)
                await db.update_verify_status(
                    user_id,
                    verify_token=token,
                    is_verified=False,
                    original_start=original_cmd,
                    link=shortlink
                )

                btn = [
                    [InlineKeyboardButton("Oᴘєη ʟιηк", url=masked_link),
                     InlineKeyboardButton("Tυтσʀιαℓ", url=TUT_VID)],
                    [InlineKeyboardButton("Bυу Pʀємιυм", callback_data="premium")]
                ]
                return await message.reply(
                    f"Your token has expired. Please refresh to continue..\n\n"
                    f"<b>Token Timeout:</b> {get_exp_time(VERIFY_EXPIRE)}\n\n"
                    "<b>What is token?</b>\n"
                    f"Pass one ad to use bot for {get_exp_time(VERIFY_EXPIRE)}",
                    reply_markup=InlineKeyboardMarkup(btn)
                )

        # === SEND FILE (VERIFIED OR PREMIUM) ===
        try:
            base64_string = text.split(" ", 1)[1]
        except:
            return

        decoded_string = await decode(base64_string)
        argument = decoded_string.split("-")
        ids = []

        if len(argument) == 3:
            try:
                start = int(int(argument[1]) / abs(client.db_channel.id))
                end = int(int(argument[2]) / abs(client.db_channel.id))
                ids = range(start, end + 1) if start <= end else list(range(start, end - 1, -1))
            except:
                return
        elif len(argument) == 2:
            try:
                ids = [int(int(argument[1]) / abs(client.db_channel.id))]
            except:
                return

        temp_msg = await message.reply("<b>Please wait...</b>")
        try:
            messages = await get_messages(client, ids)
        except:
            await message.reply_text("Something went wrong!")
            return
        finally:
            await temp_msg.delete()

        codeflix_msgs = []
        for msg in messages:
            caption = (CUSTOM_CAPTION.format(
                previouscaption="" if not msg.caption else msg.caption.html,
                filename=msg.document.file_name if msg.document else "File"
            ) if CUSTOM_CAPTION and msg.document else
               ("" if not msg.caption else msg.caption.html))

            reply_markup = msg.reply_markup if not DISABLE_CHANNEL_BUTTON else None

            try:
                copied_msg = await msg.copy(
                    chat_id=message.from_user.id,
                    caption=caption,
                    parse_mode=ParseMode.HTML,
                    reply_markup=reply_markup,
                    protect_content=settings['protect_content']
                )
                codeflix_msgs.append(copied_msg)
            except FloodWait as e:
                await asyncio.sleep(e.x)
                copied_msg = await msg.copy(
                    chat_id=message.from_user.id,
                    caption=caption,
                    parse_mode=ParseMode.HTML,
                    reply_markup=reply_markup,
                    protect_content=settings['protect_content']
                )
                codeflix_msgs.append(copied_msg)
            except:
                pass

        if FILE_AUTO_DELETE > 0:
            notification_msg = await message.reply(
                f"<b>File will be deleted in {get_exp_time(FILE_AUTO_DELETE)}. Save it now.</b>"
            )
            await asyncio.sleep(FILE_AUTO_DELETE)
            for snt_msg in codeflix_msgs:
                if snt_msg:
                    try:
                        await snt_msg.delete()
                    except:
                        pass
            try:
                reload_url = f"https://t.me/{client.username}?start={text.split(' ', 1)[1]}"
                keyboard = InlineKeyboardMarkup([
                    [InlineKeyboardButton("GET FILE AGAIN", url=reload_url)]
                ])
                await notification_msg.edit(
                    "<b>File deleted!\nClick to get again</b>",
                    reply_markup=keyboard
                )
            except:
                pass

    else:
        buttons = [
            [
                InlineKeyboardButton("мσνιє'ѕ", url="https://t.me/Movies8777"),
                InlineKeyboardButton("нєηαтєє", url="https://t.me/+1epnsIzoCx43YTk1")
            ],
            [
                InlineKeyboardButton("ᴀʙᴏᴜᴛ", callback_data="about"),
                InlineKeyboardButton("ʜᴇʟᴘ", callback_data="help")
            ]
        ]

        if await is_admin(message.from_user.id):
            buttons.append([
                InlineKeyboardButton("ᴀᴅᴍɪɴ ᴄᴏᴍᴍᴀɴᴅs", callback_data="admin_cmds_1"),
                InlineKeyboardButton("📊 sᴛᴀᴛs", callback_data="stats")
            ])

        reply_markup = InlineKeyboardMarkup(buttons)
        caption = START_MSG.format(
            first=message.from_user.first_name,
            last=message.from_user.last_name,
            username=None if not message.from_user.username else '@' + message.from_user.username,
            mention=message.from_user.mention,
            id=message.from_user.id
        )

        await message.reply_photo(
            photo=START_PIC,
            caption=caption,
            reply_markup=reply_markup,
            message_effect_id=5104841245755180586
        )

#=====================================================================================##


async def not_joined(client: Client, message: Message):
    temp = await message.reply("<b><i>Checking Subscription...</i></b>")
    user_id = message.from_user.id
    buttons = []
    count = 0

    try:
        all_channels = await db.show_channels()
        for total, chat_id in enumerate(all_channels, start=1):
            mode = await db.get_channel_mode(chat_id)
            await message.reply_chat_action(ChatAction.TYPING)

            if not await is_sub(client, user_id, chat_id):
                try:
                    if chat_id in chat_data_cache:
                        data = chat_data_cache[chat_id]
                    else:
                        data = await client.get_chat(chat_id)
                        chat_data_cache[chat_id] = data
                    name = data.title

                    if mode == "on" and not data.username:
                        invite = await client.create_chat_invite_link(
                            chat_id=chat_id,
                            creates_join_request=True,
                            expire_date=datetime.utcnow() + timedelta(seconds=FSUB_LINK_EXPIRY) if FSUB_LINK_EXPIRY else None
                        )
                        link = invite.invite_link
                    else:
                        if data.username:
                            link = f"https://t.me/{data.username}"
                        else:
                            invite = await client.create_chat_invite_link(
                                chat_id=chat_id,
                                expire_date=datetime.utcnow() + timedelta(seconds=FSUB_LINK_EXPIRY) if FSUB_LINK_EXPIRY else None
                            )
                            link = invite.invite_link

                    buttons.append([InlineKeyboardButton(text=name, url=link)])
                    count += 1
                    await temp.edit(f"<b>{'! ' * count}</b>")

                except Exception as e:
                    print(f"Error with chat {chat_id}: {e}")
                    return await temp.edit(
                        f"<b><i>! Eʀʀᴏʀ, Cᴏɴᴛᴀᴄᴛ ᴅᴇᴠᴇʟᴏᴘᴇʀ ᴛᴏ sᴏʟᴠᴇ ᴛʜᴇ ɪssᴜᴇs @Goathunterr</i></b>\n"
                        f"<blockquote expandable><b>Rᴇᴀsᴏɴ:</b> {e}</blockquote>"
                    )

        try:
            buttons.append([
                InlineKeyboardButton(
                    text='♻️ Tʀʏ Aɢᴀɪn',
                    url=f"https://t.me/{client.username}?start={message.command[1]}"
                )
            ])
        except IndexError:
            pass

        await message.reply_photo(
            photo=FORCE_PIC,
            caption=FORCE_MSG.format(
                first=message.from_user.first_name,
                last=message.from_user.last_name,
                username=None if not message.from_user.username else '@' + message.from_user.username,
                mention=message.from_user.mention,
                id=message.from_user.id
            ),
            reply_markup=InlineKeyboardMarkup(buttons),
        )
    except Exception as e:
        print(f"Final Error: {e}")
        await temp.edit(
            f"<b><i>! Eʀʀᴏʀ, Cᴏɴᴛᴀᴄᴛ ᴅᴇᴠᴇʟᴏᴘᴇʀ ᴛᴏ sᴏʟᴠᴇ ᴛʜᴇ ɪssᴜᴇs @Goathunterr</i></b>\n"
            f"<blockquote expandable><b>Rᴇᴀsᴏɴ:</b> {e}</blockquote>"
        )


#=====================================================================================##


@Bot.on_message(filters.command('myplan') & filters.private)
async def check_plan(client: Client, message: Message):
    user_id = message.from_user.id
    status_message = await check_user_plan(user_id)
    await message.reply(status_message)


#=====================================================================================##


@Bot.on_message(filters.command('addpremium') & filters.private & admin)
async def add_premium_user_command(client, msg):
    if len(msg.command) != 4:
        await msg.reply_text(
            "Usage: /addpremium <user_id> <time_value> <time_unit>\n\n"
            "Time Units:\n"
            "s - seconds\n"
            "m - minutes\n"
            "h - hours\n"
            "d - days\n"
            "y - years\n\n"
            "Examples:\n"
            "/addpremium 123456789 30 m → 30 minutes\n"
            "/addpremium 123456789 2 h → 2 hours\n"
            "/addpremium 123456789 1 d → 1 day\n"
            "/addpremium 123456789 1 y → 1 year"
        )
        return

    try:
        user_id = int(msg.command[1])
        time_value = int(msg.command[2])
        time_unit = msg.command[3].lower()

        expiration_time = await add_premium(user_id, time_value, time_unit)

        await msg.reply_text(
            f"✅ User `{user_id}` added as a premium user for {time_value} {time_unit}.\n"
            f"Expiration Time: `{expiration_time}`"
        )

        await client.send_message(
            chat_id=user_id,
            text=(
                f"🎉 Premium Activated!\n\n"
                f"You have received premium access for `{time_value} {time_unit}`.\n"
                f"Expires on: `{expiration_time}`"
            ),
        )
    except ValueError:
        await msg.reply_text("❌ Invalid input. Please ensure user ID and time value are numbers.")
    except Exception as e:
        await msg.reply_text(f"⚠️ An error occurred: `{str(e)}`")


#=====================================================================================##


@Bot.on_message(filters.command('remove_premium') & filters.private & admin)
async def pre_remove_user(client: Client, msg: Message):
    if len(msg.command) != 2:
        await msg.reply_text("usage: /remove_premium user_id ")
        return
    try:
        user_id = int(msg.command[1])
        await remove_premium(user_id)
        await msg.reply_text(f"User {user_id} has been removed.")
    except ValueError:
        await msg.reply_text("user_id must be an integer or not available in database.")


#=====================================================================================##


@Bot.on_message(filters.command('premium_users') & filters.private & admin)
async def list_premium_users_command(client, message):
    ist = timezone("Asia/Kolkata")
    premium_users_cursor = collection.find({})
    premium_user_list = ['Active Premium Users in database:']
    current_time = datetime.now(ist)

    async for user in premium_users_cursor:
        user_id = user["user_id"]
        expiration_timestamp = user["expiration_timestamp"]
        try:
            expiration_time = datetime.fromisoformat(expiration_timestamp).astimezone(ist)
            remaining_time = expiration_time - current_time

            if remaining_time.total_seconds() <= 0:
                await collection.delete_one({"user_id": user_id})
                continue

            user_info = await client.get_users(user_id)
            username = user_info.username if user_info.username else "No Username"
            first_name = user_info.first_name
            mention = user_info.mention

            days, hours, minutes, seconds = (
                remaining_time.days,
                remaining_time.seconds // 3600,
                (remaining_time.seconds // 60) % 60,
                remaining_time.seconds % 60,
            )
            expiry_info = f"{days}d {hours}h {minutes}m {seconds}s left"

            premium_user_list.append(
                f"UserID: <code>{user_id}</code>\n"
                f"User: @{username}\n"
                f"Name: {mention}\n"
                f"Expiry: {expiry_info}"
            )
        except Exception as e:
            premium_user_list.append(
                f"UserID: <code>{user_id}</code>\n"
                f"Error: Unable to fetch user details ({str(e)})"
            )

    if len(premium_user_list) == 1:
        await message.reply_text("I found 0 active premium users in my DB")
    else:
        await message.reply_text("\n\n".join(premium_user_list), parse_mode=None)


#=====================================================================================##


@Bot.on_message(filters.command("count") & filters.private & admin)
async def total_verify_count_cmd(client, message: Message):
    total = await db.get_total_verify_count()
    await message.reply_text(f"Tᴏᴛᴀʟ ᴠᴇʀɪғɪᴇᴅ ᴛᴏᴋᴇɴs ᴛᴏᴅᴀʏ: <b>{total}</b>")


@Bot.on_message(filters.command('settings') & filters.user(OWNER_ID) & filters.private)
async def owner_settings(client: Client, message: Message):
    settings = await db.get_settings()
    text = (
        "<b>🛠 Oᴡɴᴇʀ Sᴇᴛᴛɪɴɢs</b>\n\n"
        f"<b>Sʜᴏʀᴛʟɪɴᴋ Uʀʟ:</b> <code>{settings['shortlink_url']}</code>\n"
        f"<b>Sʜᴏʀᴛʟɪɴᴋ Aᴘɪ:</b> <code>{settings['shortlink_api']}</code>\n"
        f"<b>Sʜᴏʀᴛʟɪɴᴋ Sᴛᴀᴛᴜs:</b> {'ON' if settings['is_shortlink'] else 'OFF'}\n"
        f"<b>Pʀᴏᴛᴇᴄᴛ Cᴏɴᴛᴇɴᴛ:</b> {'ON' if settings['protect_content'] else 'OFF'}\n\n"
        "<i>Use /set_url to change URL and /set_api to change API.</i>"
    )
    buttons = [
        [
            InlineKeyboardButton(f"Sʜᴏʀᴛʟɪɴᴋ: {'ON' if settings['is_shortlink'] else 'OFF'}", callback_data="toggle_shortlink"),
            InlineKeyboardButton(f"Pʀᴏᴛᴇᴄᴛ: {'ON' if settings['protect_content'] else 'OFF'}", callback_data="toggle_protect")
        ],
        [
            InlineKeyboardButton("Tᴇsᴛ Sʜᴏʀᴛʟɪɴᴋ", callback_data="test_shortlink"),
            InlineKeyboardButton("Cʟᴏsᴇ", callback_data="close")
        ]
    ]
    await message.reply_photo(photo=START_PIC, caption=text, reply_markup=InlineKeyboardMarkup(buttons))

@Bot.on_message(filters.command('set_url') & filters.user(OWNER_ID) & filters.private)
async def set_shortlink_url(client: Client, message: Message):
    if len(message.command) < 2:
        return await message.reply_text("<b>Usage:</b> <code>/set_url inshorturl.com</code>")
    url = message.command[1]
    await db.update_setting('shortlink_url', url)
    await message.reply_text(f"<b>✅ Shortlink URL updated to:</b> <code>{url}</code>")

@Bot.on_message(filters.command('set_api') & filters.user(OWNER_ID) & filters.private)
async def set_shortlink_api(client: Client, message: Message):
    if len(message.command) < 2:
        return await message.reply_text("<b>Usage:</b> <code>/set_api YOUR_API_KEY</code>")
    api = message.command[1]
    await db.update_setting('shortlink_api', api)
    await message.reply_text(f"<b>✅ Shortlink API updated to:</b> <code>{api}</code>")
